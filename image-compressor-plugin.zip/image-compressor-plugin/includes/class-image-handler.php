<?php
if (!defined('ABSPATH')) exit;

class Image_Handler {
    public static function compress_image($image_path, $quality) {
        $info = getimagesize($image_path);
        if (!$info || !isset($info['mime'])) return false;

        $mime = $info['mime'];
        $image = null;

        switch ($mime) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($image_path);
                ob_start();
                imagejpeg($image, null, $quality);
                break;
            case 'image/png':
                $image = imagecreatefrompng($image_path);
                ob_start();
                imagepng($image);
                break;
            case 'image/gif':
                $image = imagecreatefromgif($image_path);
                ob_start();
                imagegif($image);
                break;
            default:
                return false; // Unsupported format
        }

        $compressed_data = ob_get_clean();
        imagedestroy($image);

        return $compressed_data;
    }

    public static function handle_ajax_request() {
        check_ajax_referer('image_compressor_nonce', 'security');

        $image_id = intval($_POST['image_id']);
        $quality = intval($_POST['quality']);
        $replace = isset($_POST['replace']) && $_POST['replace'] === 'true';

        if ($quality < 10 || $quality > 100) {
            wp_send_json_error(['message' => 'Quality must be between 10 and 100.']);
            return;
        }

        $image_path = sanitize_text_field(get_attached_file($image_id));
        if (!file_exists($image_path)) {
            wp_send_json_error(['message' => 'File does not exist.']);
            return;
        }

        $original_size = filesize($image_path);
        $compressed_data = self::compress_image($image_path, $quality);

        if ($compressed_data) {
            // Replace the original file
            if ($replace) {
                file_put_contents($image_path, $compressed_data);
                clearstatcache(true, $image_path); // Clear file cache
                $new_size = filesize($image_path);

                // Update WordPress metadata to refresh the file details
                wp_update_attachment_metadata($image_id, wp_generate_attachment_metadata($image_id, $image_path));

                wp_send_json_success([
                    'message'       => 'File replaced successfully.',
                    'original_size' => size_format($original_size),
                    'new_size'      => size_format($new_size),
                    'saved_space'   => size_format($original_size - $new_size)
                ]);
            } else {
                // Save compressed file alongside original if not replacing
                $new_path = pathinfo($image_path, PATHINFO_DIRNAME) . '/' . pathinfo($image_path, PATHINFO_FILENAME) . '-compressed.' . pathinfo($image_path, PATHINFO_EXTENSION);
                file_put_contents($new_path, $compressed_data);
                $new_size = filesize($new_path);

                wp_send_json_success([
                    'message'       => 'File compressed successfully.',
                    'original_size' => size_format($original_size),
                    'new_size'      => size_format($new_size),
                    'saved_space'   => size_format($original_size - $new_size),
                    'new_file_url'  => wp_get_attachment_url($image_id)
                ]);
            }
        } else {
            wp_send_json_error(['message' => 'Compression failed.']);
        }
    }
}

add_action('wp_ajax_compress_image', ['Image_Handler', 'handle_ajax_request']);
